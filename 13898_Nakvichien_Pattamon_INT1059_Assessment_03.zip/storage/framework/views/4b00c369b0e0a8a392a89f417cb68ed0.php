<?php $__env->startSection('content'); ?>
    <div class="movie-info border-b border-gray-800">
        <div class="container mx-auto px-4 py-16 flex flex-col md:flex-row">
            <div class="flex-none">
                <img src="<?php echo e('https://image.tmdb.org/t/p/w500/'.$movie['poster_path']); ?>" alt="poster" class="sm:w-64 lg:w-96">
            </div>
            <div class="md:ml-24">
                <h2 class="text-4xl font-semibold"><?php echo e($movie['title']); ?> (2019)</h2>
                <div class="flex flex-wrap items-center text-gray-400 text-sm">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1" stroke="currentColor" class="fill-current w-4 text-yellow-500">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z" />
                        </svg>
                    </span>
                    <span class="ml-1"><?php echo e(round($movie['vote_average'] * 10).'%'); ?></span>
                    <span class="mx-2">|</span>
                    <span><?php echo e(\Carbon\Carbon::parse($movie['release_date'])->format('d M Y')); ?></span>
                    <span class="mx-2">|</span>
                    <span>
                    <?php $__currentLoopData = $movie['genres']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($genre['name']); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </div>
                <p class="text-gray-300 mt-8">
                    <?php echo e($movie['overview']); ?>

                </p>
                <div class="mt-12">
                    <h4 class="text-white font-semibold">Featured Crew</h4>
                    <div class="flex mt-4">
                        <?php $__currentLoopData = $movie['credits']['crew']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->index < 2): ?>
                                <div class="mr-8">
                                    <div><?php echo e($crew['name']); ?></div>
                                    <div class="text-sm text-gray-400"><?php echo e($crew['job']); ?></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php if(count($movie['videos']['results']) > 0): ?>
                    <div class="mt-12">
                        <a href="https://youtube.com/watch?v=<?php echo e($movie['videos']['results'][0]['key']); ?>" class="inline-flex items-center bg-orange-500 text-gray-900 rounded font-semibold px-5 py-4 hover:bg-orange-600 transition ease-in-out duration-150">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z" />
                                </svg>
                            </span>
                            <span class="ml-2">Play Trailer</span>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div> <!-- end movie-info -->

    <div class="movie-cast border-b border-gray-800">
        <div class="container mx-auto px-4 py-16">
            <h2 class="text-4xl font-semibold">Cast</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
                <?php $__currentLoopData = $movie['credits']['cast']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 5): ?>
                        <div class="mt-8">
                            <a href="#">
                                <img class="hover:opacity-75 transition ease-in-out duration-200" src="https://image.tmdb.org/t/p/w300/<?php echo e($cast['profile_path']); ?>" alt="<?php echo e($cast['name']); ?> Photo" >
                            </a>
                            <div class="mt-2">
                                <a href="#" class="text-lg mt-2 hover:text-gray:300"><?php echo e($cast['name']); ?></a>
                                <div class="text-sm text-gray-400"><?php echo e($cast['character']); ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div> <!-- end movie-cast -->

    <div class="movie-images">
        <div class="container mx-auto px-4 py-16">
            <h2 class="text-4xl font-semibold">Images</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
                <?php $__currentLoopData = $movie['images']['backdrops']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 9): ?>
                        <div class="mt-8">
                            <a href="#">
                                <img class="hover:opacity-75 transition ease-in-out duration-200" src="https://image.tmdb.org/t/p/w500/<?php echo e($image['file_path']); ?>" alt="<?php echo e($movie['title']); ?> Image" >
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div> <!-- end movie-images -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/patty/Projects/AIT/advanced-web/assigment-3/primepix-submission/resources/views/show.blade.php ENDPATH**/ ?>