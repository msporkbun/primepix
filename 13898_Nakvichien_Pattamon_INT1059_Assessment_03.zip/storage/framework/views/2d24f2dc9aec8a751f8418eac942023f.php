<div>
    
</div>
<?php /**PATH /Users/patty/Projects/AIT/advanced-web/primepix/resources/views/livewire/search-dropdown.blade.php ENDPATH**/ ?>