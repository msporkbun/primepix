<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 pt-16">
        <h2 class="uppercase tracking-wider text-orange-500 text-lg font-semibold">Popular Movies</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
            <?php $__currentLoopData = $popularMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6 = $attributes; } ?>
<?php $component = App\View\Components\MovieCard::resolve(['movie' => $movie,'genres' => $genres] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('movie-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MovieCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6)): ?>
<?php $attributes = $__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6; ?>
<?php unset($__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6)): ?>
<?php $component = $__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6; ?>
<?php unset($__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="now-playing-movies py-24">
            <h2 class="uppercase tracking-wider text-orange-500 text-lg font-semibold">Now Playing Movies</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
                <?php $__currentLoopData = $nowPlayingMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6 = $attributes; } ?>
<?php $component = App\View\Components\MovieCard::resolve(['movie' => $movie,'genres' => $genres] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('movie-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MovieCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6)): ?>
<?php $attributes = $__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6; ?>
<?php unset($__attributesOriginal6e34be0b1fcc8536181a4dcca14a30e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6)): ?>
<?php $component = $__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6; ?>
<?php unset($__componentOriginal6e34be0b1fcc8536181a4dcca14a30e6); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/patty/Projects/AIT/advanced-web/assigment-3/primepix-submission/resources/views/index.blade.php ENDPATH**/ ?>